<!DOCTYPE html>
<html>
  <?php require_once('session.php'); ?>
  <?php require_once('header.php'); ?>
  
<body >

<?php require_once('nav.php'); ?>
  

  <main class="container"> 
    <div class="row"> 
      <div align="center" class="col s# m# l#">
        <!-- html-->
    </div> 
   </div>   
  </main>


<?php require_once('footer.php'); ?>
  </body>
</html>






