
<nav style="height: 70px;padding-top: 10px; padding-bottom: 10px;">
    <div class="nav-wrapper container">
    <a href="#!" class="brand-logo center">
        <img width="158"  class"responsive-img" src="img/logo_75.png">

    </div>

 <li id="menu-item-49317" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children submenu"><a href="https://www.zamorano.edu/admisiones/"><span>Admisiones</span></a>
<ul style="display: none;" class="sub-menu">
  <li id="menu-item-49320" class="menu-item menu-item-type-post_type menu-item-object-page"><a href=""><span></span></a></li>
  <li id="menu-item-50039" class="menu-item menu-item-type-post_type menu-item-object-page"><a href=""><span></span></a></li>
  <li id="menu-item-49319" class="menu-item menu-item-type-post_type menu-item-object-page last-item"><a href=""><span></span></a></li>
</ul>
<span class="menu-toggle"></span></li>


  </nav>
    <div class="menu_wrapper">
          <nav role="navigation">
    <div class="nav-wrapper container">
      <ul class="left hide-on-med-and-down">
        <li class="dropdown-button" href="https://www.zamorano.edu/admisiones/porque-zamorano/" data-activates="dropdown1" ><a href="https://www.zamorano.edu/admisiones">Admisiones</a></li>
        <li><a href="https://www.zamorano.edu/carreras">Carreras</a></li>
        <li><a href="https://www.zamorano.edu/sobre-zamorano/">Sobre Zamorano</a></li>
        <li><a href="https://www.zamorano.edu/vida-en-el-campus/">Vida en el Campus</a></li>
        <li><a href="https://www.zamorano.edu/graduados/">Graduados</a></li>
      </ul>

      <ul id="nav-mobile" class="light-blue lighten-1 side-nav">
        <div align="center" class="image_wrapper">
          <p></p>
          <a href="https://www.zamorano.edu"><img class="scale-with-grid" src="img/logo_75.png" alt="actualizate_" width="158" height="37"></a>
        </div>
        <li><a href="https://www.zamorano.edu/admisiones">Admisiones</a></li>
        <li><a href="https://www.zamorano.edu/carreras">Carreras</a></li>
        <li><a href="https://www.zamorano.edu/sobre-zamorano/">Sobre Zamorano</a></li>
        <li><a href="https://www.zamorano.edu/vida-en-el-campus/">Vida en el Campus</a></li>
        <li><a href="https://www.zamorano.edu/graduados/">Graduados</a></li>
      </ul>
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
    </div>
  </nav>
    <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>
